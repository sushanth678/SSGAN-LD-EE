# SSGAN-LD-EE

To run the model : python main.py<br>
To generate images from trained model :

1. Open test.ipynb
2. Set model_name (1st cell of the notebook) to the name of the model that is to be tested.
3. Run all cells. Last cell has 100 generated images.
